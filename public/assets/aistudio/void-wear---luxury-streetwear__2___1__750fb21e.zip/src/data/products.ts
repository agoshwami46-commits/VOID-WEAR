import { Product, Review } from '../types';

export const OFFICIAL_LOGO_URL = '/void-logo.jpg';

export const INITIAL_PRODUCTS: Product[] = [
  {
    "name": "THE SAMURAI ACID WASH {HOODIE}",
    "sku": "VW-10001",
    "category": "HOODIES",
    "tagline": "HEAVYWEIGHT UNISEX OVERSIZED HOODIE",
    "price": 2299,
    "badge": "NEW DROP",
    "description": "Product Name: Acid Wash Hoodie – The Samurai (Voidwear Samurai Collection)   Product OverviewUnleash your inner warrior with \"The Samurai\" acid wash hoodie from Voidwear. Part of the exclusive Samurai Collection, this piece embodies the ethos: \"Same essence, different colors, bolder you.\" Featuring a stunning, intricate graphic of a samurai against a vivid crimson sun and falling cherry blossoms, it merges traditional Japanese aesthetics with rugged, modern streetwear design.   Key FeaturesAcid Wash Texture: Unique distressed vintage wash finish that gives each hoodie an edgy, one-of-a-kind look and texture.   Striking Back Graphic: High-impact artwork showcasing a legendary samurai set against a bold red backdrop and dynamic cherry blossom accents.   Oversized Fit: Tailored with a relaxed, modern drop-shoulder silhouette for maximum street style and comfortable layering.   All-Season Comfort: Crafted from a soft, breathable fabric blend designed to keep you comfortable year-round.   Durable Print: High-definition print technology ensures the rich reds and deep monochrome details stay sharp and vibrant wash after wash.   Specifications & CareBrand/Collection: Voidwear – Samurai Collection   Material: Premium Cotton Blend   Fit Type: Oversized Fit   Texture: Acid Wash   Care Instructions: Machine wash cold inside out with like colors. Tumble dry low or hang dry. Do not iron directly on the graphic.The MessageSame Essence. Different Colors. Bolder You.",
    "gsm": 280,
    "fabric": "100% Ultra-Dense Combed Cotton",
    "fit": "Signature Boxy Oversized Silhouette",
    "sizes": [
      "S",
      "M",
      "L",
      "XL",
      "XXL"
    ],
    "colors": [
      {
        "images": [
          "/uploads/1793431132876_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431146877_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431173367_whatsapp_image_2026_10_31_at_12_.jpeg"
        ],
        "name": "Pitch Black",
        "hex": "#0B0B0B",
        "family": "Black"
      },
      {
        "family": "Green",
        "images": [
          "/uploads/1793431132876_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431146877_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431173367_whatsapp_image_2026_10_31_at_12_.jpeg"
        ],
        "name": "Forest Pine Green",
        "hex": "#243828"
      },
      {
        "family": "Blue",
        "name": "Deep Cobalt Blue",
        "images": [
          "/uploads/1793431132876_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431146877_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431173367_whatsapp_image_2026_10_31_at_12_.jpeg"
        ],
        "hex": "#162A43"
      }
    ],
    "images": [
      "/uploads/1793431132876_whatsapp_image_2026_10_31_at_12_.jpeg",
      "/uploads/1793431146877_whatsapp_image_2026_10_31_at_12_.jpeg",
      "/uploads/1793431173367_whatsapp_image_2026_10_31_at_12_.jpeg"
    ],
    "inStock": true,
    "stockCount": 25,
    "isPublished": true,
    "details": [
      "Heavyweight 280 GSM luxury knit",
      "Reinforced rib neckline",
      "Distressed rear insignia"
    ],
    "careInstructions": [
      "Machine wash cold inside out",
      "Hang dry in shade",
      "Do not bleach"
    ],
    "featured": true,
    "originalPrice": 3500,
    "backImage": "/uploads/1793431146877_whatsapp_image_2026_10_31_at_12_.jpeg",
    "sideImage": "/uploads/1793431173367_whatsapp_image_2026_10_31_at_12_.jpeg",
    "angles": [
      {
        "label": "FRONT ANGLE",
        "angle": "FRONT",
        "url": "/uploads/1793431132876_whatsapp_image_2026_10_31_at_12_.jpeg"
      },
      {
        "url": "/uploads/1793431146877_whatsapp_image_2026_10_31_at_12_.jpeg",
        "angle": "BACK",
        "label": "REAR PROFILE"
      },
      {
        "label": "SIDE SILHOUETTE",
        "url": "/uploads/1793431173367_whatsapp_image_2026_10_31_at_12_.jpeg",
        "angle": "SIDE"
      }
    ],
    "id": "void-mvw2r5ch",
    "slug": "void-mvw2r5ch",
    "createdAt": "2026-10-31T07:23:27.093Z",
    "updatedAt": "2026-10-31T07:23:26.034Z"
  },
  {
    "id": "void-mvw27kni",
    "sizes": [
      "S",
      "M",
      "L",
      "XL",
      "XXL"
    ],
    "stockCount": 25,
    "details": [
      "Heavyweight 280 GSM luxury knit",
      "Reinforced rib neckline",
      "Distressed rear insignia"
    ],
    "price": 1999,
    "updatedAt": "2026-10-31T07:11:06.201Z",
    "fit": "Signature Boxy Oversized Silhouette",
    "slug": "void-mvw27kni",
    "badge": "NEW DROP",
    "name": "bleeding butterfly {hoodie}",
    "sideImage": "/uploads/1793430061529_whatsapp_image_2026_10_31_at_1_2.jpeg",
    "gsm": 280,
    "sku": "VW-10000",
    "category": "HOODIES",
    "tagline": "HEAVYWEIGHT OVERSIZED UNISEX HOODIE",
    "featured": true,
    "createdAt": "2026-10-31T07:08:13.519Z",
    "description": "Product Name: Bleeding Butterfly (Voidwear Butterfly Collection)\n\nProduct Overview\nStep beyond the ordinary with the \"Bleeding Butterfly\" oversized hoodie from Voidwear. Built for those who wear their transformation boldly, this piece blends striking, raw aesthetics with uncompromising comfort. Featuring an intense splattered butterfly graphic across the back, it symbolizes freedom, evolution, and the grit required to become a stronger you.\n\nKey Features\nOversized Fit: Engineered with a modern, relaxed drop-shoulder silhouette for maximum streetwear appeal and effortless layering.\n\nStriking Back Graphic: High-impact \"Bleeding Butterfly\" artwork contrasting sharp white, monochrome, and vivid crimson splatters against a deep black canvas.\n\nPremium Cotton Blend: Crafted from a heavy, ultra-soft fabric blend that delivers cozy warmth, breathability, and structural durability.\n\nDurable Fade-Resistant Print: High-definition printing technology ensures the intricate splatters and bold contrast stay vibrant wash after wash.\n\nSpecifications & Care\nMaterial: Premium Cotton Blend (Heavyweight fleece interior for winter/evening wear)\n\nFit Type: Oversized / Relaxed Streetwear Fit\n\nStyle: Pullover Hoodie with adjustable drawstrings and a spacious kangaroo pocket\n\nCare Instructions: Machine wash cold inside out with like colors. Tumble dry low or hang dry to preserve print longevity. Do not iron directly on the graphic.\n\nThe Message\nFreedom. Transformation. A Stronger You.",
    "careInstructions": [
      "Machine wash cold inside out",
      "Hang dry in shade",
      "Do not bleach"
    ],
    "inStock": true,
    "isPublished": true,
    "fabric": "100% Ultra-Dense Combed Cotton",
    "backImage": "/uploads/1793430050696_whatsapp_image_2026_10_31_at_1_2.jpeg",
    "colors": [
      {
        "name": "Pitch Black",
        "family": "Black",
        "hex": "#0B0B0B",
        "images": [
          "/uploads/1793430041332_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793430050696_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793430061529_whatsapp_image_2026_10_31_at_1_2.jpeg"
        ]
      },
      {
        "hex": "#EDECE8",
        "family": "White",
        "images": [
          "/uploads/1793430041332_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793430050696_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793430061529_whatsapp_image_2026_10_31_at_1_2.jpeg"
        ],
        "name": "Chalk Ivory"
      },
      {
        "family": "Blue",
        "hex": "#162A43",
        "images": [
          "/uploads/1793430041332_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793430050696_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793430061529_whatsapp_image_2026_10_31_at_1_2.jpeg"
        ],
        "name": "Deep Cobalt Blue"
      },
      {
        "name": "Forest Pine Green",
        "images": [
          "/uploads/1793430041332_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793430050696_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793430061529_whatsapp_image_2026_10_31_at_1_2.jpeg"
        ],
        "hex": "#243828",
        "family": "Green"
      },
      {
        "hex": "#ffb8f0",
        "name": "BABY PINK",
        "family": "Other",
        "images": [
          "/uploads/1793430041332_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793430050696_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793430061529_whatsapp_image_2026_10_31_at_1_2.jpeg"
        ]
      },
      {
        "images": [
          "/uploads/1793430041332_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793430050696_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793430061529_whatsapp_image_2026_10_31_at_1_2.jpeg"
        ],
        "name": "MAROON",
        "family": "Other",
        "hex": "#730c0c"
      }
    ],
    "images": [
      "/uploads/1793430041332_whatsapp_image_2026_10_31_at_1_2.jpeg",
      "/uploads/1793430050696_whatsapp_image_2026_10_31_at_1_2.jpeg",
      "/uploads/1793430061529_whatsapp_image_2026_10_31_at_1_2.jpeg"
    ],
    "angles": [
      {
        "angle": "FRONT",
        "label": "FRONT ANGLE",
        "url": "/uploads/1793430041332_whatsapp_image_2026_10_31_at_1_2.jpeg"
      },
      {
        "url": "/uploads/1793430050696_whatsapp_image_2026_10_31_at_1_2.jpeg",
        "label": "REAR PROFILE",
        "angle": "BACK"
      },
      {
        "angle": "SIDE",
        "url": "/uploads/1793430061529_whatsapp_image_2026_10_31_at_1_2.jpeg",
        "label": "SIDE SILHOUETTE"
      }
    ]
  },
  {
    "id": "void-mvw39667",
    "createdAt": "2026-10-31T07:37:28.050Z",
    "isPublished": true,
    "badge": "NEW DROP",
    "category": "HOODIES",
    "gsm": 280,
    "fabric": "100% Ultra-Dense Combed Cotton",
    "name": "THE FLORA {HOODIE}",
    "updatedAt": "2026-10-31T07:37:26.911Z",
    "sku": "VW-10002",
    "description": "Product Name: Oversized Hoodie – The Flora (Voidwear Floral Collection)   \n\n\nProduct Overview\nEmbrace a balance of striking contrast and delicate elegance with \"The Flora\" hoodie from Voidwear. Part of the exclusive Floral Collection, this piece follows the brand's core philosophy: \"Same essence, different colors, bolder you.\" Featuring a stunning back graphic of blooming floral artistry against a clean, deep black canvas, it combines nature-inspired beauty with modern streetwear style.   \nWhatsApp Image 2026-10-31 at 12.06.02 AM.jpeg\n+ 1\n\nKey Features\nStriking Floral Back Graphic: High-impact artwork showcasing blooming white and crimson floral arrangements intertwined with dark, moody foliage.   \nWhatsApp Image 2026-10-31 at 12.06.02 AM.jpeg\n\nOversized Fit: Designed with a relaxed, modern drop-shoulder silhouette for ultimate streetwear comfort and effortless layering.   \nWhatsApp Image 2026-10-31 at 12.06.02 AM.jpeg\n\nPremium Cotton Blend: Crafted from a soft, high-quality fabric blend built to keep you cozy and breathable throughout the year.   \nWhatsApp Image 2026-10-31 at 12.06.02 AM.jpeg\n\nDurable Print: High-definition printing technology ensures the intricate details and vibrant color contrasts stay sharp wash after wash.   \nWhatsApp Image 2026-10-31 at 12.06.02 AM.jpeg\n\nSpecifications & Care\nBrand/Collection: Voidwear – Floral Collection   \nWhatsApp Image 2026-10-31 at 12.06.02 AM.jpeg\n\nMaterial: Premium Cotton Blend   \nWhatsApp Image 2026-10-31 at 12.06.02 AM.jpeg\n\nFit Type: Oversized Fit   \nWhatsApp Image 2026-10-31 at 12.06.02 AM.jpeg\n\nCare Instructions: Machine wash cold inside out with like colors. Tumble dry low or hang dry to preserve the fabric and print quality. Do not iron directly on the graphic.\n\nThe Message\nSame Essence. Different Colors. Bolder You",
    "sizes": [
      "S",
      "M",
      "L",
      "XL",
      "XXL"
    ],
    "sideImage": "/uploads/1793431805362_whatsapp_image_2026_10_30_at_10_.jpeg",
    "colors": [
      {
        "images": [
          "/uploads/1793431784420_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431791214_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431805362_whatsapp_image_2026_10_30_at_10_.jpeg"
        ],
        "hex": "#0B0B0B",
        "name": "Pitch Black",
        "family": "Black"
      },
      {
        "name": "Chalk Ivory",
        "hex": "#EDECE8",
        "images": [
          "/uploads/1793431784420_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431791214_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431805362_whatsapp_image_2026_10_30_at_10_.jpeg"
        ],
        "family": "White"
      },
      {
        "hex": "#243828",
        "images": [
          "/uploads/1793431784420_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431791214_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431805362_whatsapp_image_2026_10_30_at_10_.jpeg"
        ],
        "name": "Forest Pine Green",
        "family": "Green"
      },
      {
        "images": [
          "/uploads/1793431784420_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431791214_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431805362_whatsapp_image_2026_10_30_at_10_.jpeg"
        ],
        "hex": "#162A43",
        "name": "Deep Cobalt Blue",
        "family": "Blue"
      },
      {
        "hex": "#7a0000",
        "family": "Other",
        "name": "MAROON",
        "images": [
          "/uploads/1793431784420_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431791214_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431805362_whatsapp_image_2026_10_30_at_10_.jpeg"
        ]
      },
      {
        "family": "Other",
        "name": "BABY PINK",
        "hex": "#f38cc8",
        "images": [
          "/uploads/1793431784420_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431791214_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793431805362_whatsapp_image_2026_10_30_at_10_.jpeg"
        ]
      }
    ],
    "featured": true,
    "originalPrice": 3500,
    "fit": "Signature Boxy Oversized Silhouette",
    "angles": [
      {
        "url": "/uploads/1793431784420_whatsapp_image_2026_10_31_at_12_.jpeg",
        "angle": "FRONT",
        "label": "FRONT ANGLE"
      },
      {
        "angle": "BACK",
        "label": "REAR PROFILE",
        "url": "/uploads/1793431791214_whatsapp_image_2026_10_31_at_12_.jpeg"
      },
      {
        "url": "/uploads/1793431805362_whatsapp_image_2026_10_30_at_10_.jpeg",
        "label": "SIDE SILHOUETTE",
        "angle": "SIDE"
      }
    ],
    "price": 1999,
    "images": [
      "/uploads/1793431784420_whatsapp_image_2026_10_31_at_12_.jpeg",
      "/uploads/1793431791214_whatsapp_image_2026_10_31_at_12_.jpeg",
      "/uploads/1793431805362_whatsapp_image_2026_10_30_at_10_.jpeg"
    ],
    "inStock": true,
    "backImage": "/uploads/1793431791214_whatsapp_image_2026_10_31_at_12_.jpeg",
    "details": [
      "Heavyweight 280 GSM luxury knit",
      "Reinforced rib neckline",
      "Distressed rear insignia"
    ],
    "careInstructions": [
      "Machine wash cold inside out",
      "Hang dry in shade",
      "Do not bleach"
    ],
    "slug": "void-mvw39667",
    "tagline": "HEAVYWEIGHT UNISEX OVERSIZED HOODIE",
    "stockCount": 25
  },
  {
    "id": "void-mvw3mqaq",
    "backImage": "/uploads/1793432621259_whatsapp_image_2026_10_31_at_12_.jpeg",
    "fabric": "100% Ultra-Dense Combed Cotton",
    "sizes": [
      "S",
      "M",
      "L",
      "XL",
      "XXL"
    ],
    "description": "Product Name: Bleeding Butterfly Sweatshirt – Broken But Beautiful (Voidwear Butterfly Collection)   Product OverviewRedefine your street style with the \"Bleeding Butterfly\" sweatshirt from Voidwear. Guided by the motto \"Broken but beautiful\" and \"Same essence, different colors, bolder you,\" this sweatshirt features a powerful chest graphic juxtaposing a delicate, splattered butterfly against raw contrast. Available in a versatile palette of colors, it is designed for those who wear their transformation with pride.   Key FeaturesStriking Chest Graphic: High-impact \"Bleeding Butterfly\" artwork featuring sharp monochrome and vivid crimson splatters across the front.   Oversized Fit: Tailored with a relaxed, drop-shoulder streetwear silhouette for effortless comfort and styling.   Soft Cotton Blend: Crafted from a premium, all-day comfortable fabric blend built for warmth and everyday wear.   Premium Details & Durable Print: Built with high-end stitching and long-lasting print technology to keep your design vibrant wear after wear.   Color Options: Available in White, Pink, Blue, Green, and Black.   Specifications & CareBrand/Collection: Voidwear – Butterfly Collection (\"Broken But Beautiful\")   Material: Premium Cotton Blend (Soft fleece interior)   Fit Type: Oversized Fit   Available Colors: White, Pink, Blue, Green, Black   Care Instructions: Machine wash cold inside out with like colors. Tumble dry low or hang dry. Do not iron directly on the graphic.The MessageBroken But Beautiful. Same Essence. Different Colors. Bolder You.",
    "fit": "Signature Boxy Oversized Silhouette",
    "isPublished": true,
    "name": "BLEEDING BUTTERFLY {SWEATSHIRT}",
    "badge": "NEW DROP",
    "stockCount": 25,
    "originalPrice": 3500,
    "category": "HOODIES",
    "images": [
      "/uploads/1793432621257_whatsapp_image_2026_10_31_at_12_.jpeg",
      "/uploads/1793432621259_whatsapp_image_2026_10_31_at_12_.jpeg",
      "/uploads/1793432621264_whatsapp_image_2026_10_31_at_12_.jpeg"
    ],
    "angles": [
      {
        "label": "FRONT ANGLE",
        "url": "/uploads/1793432621257_whatsapp_image_2026_10_31_at_12_.jpeg",
        "angle": "FRONT"
      },
      {
        "url": "/uploads/1793432621259_whatsapp_image_2026_10_31_at_12_.jpeg",
        "label": "REAR PROFILE",
        "angle": "BACK"
      },
      {
        "label": "SIDE SILHOUETTE",
        "url": "/uploads/1793432621264_whatsapp_image_2026_10_31_at_12_.jpeg",
        "angle": "SIDE"
      }
    ],
    "gsm": 280,
    "updatedAt": "2026-10-31T08:00:02.799Z",
    "tagline": "HEAVYWEIGHT UNISEX OVERSIZED SWEATSHIRT",
    "details": [
      "Heavyweight 280 GSM luxury knit",
      "Reinforced rib neckline",
      "Distressed rear insignia"
    ],
    "sideImage": "/uploads/1793432621264_whatsapp_image_2026_10_31_at_12_.jpeg",
    "inStock": true,
    "colors": [
      {
        "images": [
          "/uploads/1793432621257_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793432621259_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793432621264_whatsapp_image_2026_10_31_at_12_.jpeg"
        ],
        "hex": "#0B0B0B",
        "name": "Pitch Black",
        "family": "Black"
      },
      {
        "family": "White",
        "hex": "#EDECE8",
        "name": "Chalk Ivory",
        "images": [
          "/uploads/1793432621257_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793432621259_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793432621264_whatsapp_image_2026_10_31_at_12_.jpeg"
        ]
      },
      {
        "hex": "#243828",
        "name": "Forest Pine Green",
        "images": [
          "/uploads/1793432621257_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793432621259_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793432621264_whatsapp_image_2026_10_31_at_12_.jpeg"
        ],
        "family": "Green"
      },
      {
        "family": "Other",
        "name": "BABY PINK",
        "hex": "#fb79d8",
        "images": [
          "/uploads/1793432621257_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793432621259_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793432621264_whatsapp_image_2026_10_31_at_12_.jpeg"
        ]
      },
      {
        "family": "Other",
        "name": "LAVENDER",
        "hex": "#a0c4f3",
        "images": [
          "/uploads/1793432621257_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793432621259_whatsapp_image_2026_10_31_at_12_.jpeg",
          "/uploads/1793432621264_whatsapp_image_2026_10_31_at_12_.jpeg"
        ]
      }
    ],
    "price": 1999,
    "featured": true,
    "createdAt": "2026-10-31T07:48:01.007Z",
    "sku": "VW-10003",
    "slug": "void-mvw3mqaq",
    "careInstructions": [
      "Machine wash cold inside out",
      "Hang dry in shade",
      "Do not bleach"
    ]
  },
  {
    "id": "void-mvw3u167",
    "badge": "NEW DROP",
    "featured": true,
    "isPublished": true,
    "name": "THE SAMURAI {HOODIE}",
    "fabric": "100% Ultra-Dense Combed Cotton",
    "fit": "Signature Boxy Oversized Silhouette",
    "description": "Product Name: The Samurai Hoodie (Voidwear Samurai Collection)   Product OverviewChannel absolute focus and inner strength with \"The Samurai\" hoodie from Voidwear. True to the collection's mantra—\"Discipline creates freedom\" and \"Same essence, different colors, bolder you\"—this piece blends timeless Japanese warrior aesthetics with cutting-edge streetwear design. Featuring a striking, highly detailed graphic of a lone samurai against a crimson blood-red moon and blooming cherry blossoms, it is built for those who command respect and move with purpose.   Key FeaturesStriking Back Graphic: High-impact, vibrant artwork showcasing a traditional samurai warrior framed by a glowing red moon and falling cherry blossom petals.   Oversized Streetwear Fit: Designed with a modern, relaxed drop-shoulder silhouette that delivers both maximum comfort and effortless style.   Premium Cotton Blend: Crafted from a soft, high-quality, heavyweight fabric blend to keep you warm, cozy, and comfortable throughout the day.   Durable, High-Definition Print: Advanced printing technology ensures the deep blacks, crisp whites, and brilliant crimsons stay sharp and vivid wash after wash.   Specifications & CareBrand/Collection: Voidwear – Samurai Collection   Material: Premium Cotton Blend (Soft fleece interior)   Fit Type: Oversized / Relaxed Fit   Care Instructions: Machine wash cold inside out with like colors. Tumble dry low or hang dry to preserve print longevity. Do not iron directly on the graphic.The MessageDiscipline Creates Freedom. Same Essence. Different Colors. Bolder You",
    "sizes": [
      "S",
      "M",
      "L",
      "XL",
      "XXL"
    ],
    "tagline": "HEAVYWEIGHT OVERSIZED UNISEX",
    "details": [
      "Heavyweight 280 GSM luxury knit",
      "Reinforced rib neckline",
      "Distressed rear insignia"
    ],
    "backImage": "/uploads/1793432985812_whatsapp_image_2026_10_30_at_11_.jpeg",
    "inStock": true,
    "price": 1999,
    "stockCount": 25,
    "category": "HOODIES",
    "sku": "VW-10004",
    "slug": "void-mvw3u167",
    "createdAt": "2026-10-31T07:53:41.245Z",
    "images": [
      "/uploads/1793432977454_whatsapp_image_2026_10_30_at_11_.jpeg",
      "/uploads/1793432985812_whatsapp_image_2026_10_30_at_11_.jpeg",
      "/uploads/1793433021364_whatsapp_image_2026_10_30_at_10_.jpeg"
    ],
    "careInstructions": [
      "Machine wash cold inside out",
      "Hang dry in shade",
      "Do not bleach"
    ],
    "angles": [
      {
        "url": "/uploads/1793432977454_whatsapp_image_2026_10_30_at_11_.jpeg",
        "label": "FRONT ANGLE",
        "angle": "FRONT"
      },
      {
        "url": "/uploads/1793432985812_whatsapp_image_2026_10_30_at_11_.jpeg",
        "label": "REAR PROFILE",
        "angle": "BACK"
      },
      {
        "label": "SIDE SILHOUETTE",
        "angle": "SIDE",
        "url": "/uploads/1793433021364_whatsapp_image_2026_10_30_at_10_.jpeg"
      }
    ],
    "sideImage": "/uploads/1793433021364_whatsapp_image_2026_10_30_at_10_.jpeg",
    "originalPrice": 3500,
    "updatedAt": "2026-10-31T08:00:17.627Z",
    "gsm": 280,
    "colors": [
      {
        "images": [
          "/uploads/1793432977454_whatsapp_image_2026_10_30_at_11_.jpeg",
          "/uploads/1793432985812_whatsapp_image_2026_10_30_at_11_.jpeg",
          "/uploads/1793433021364_whatsapp_image_2026_10_30_at_10_.jpeg"
        ],
        "hex": "#0B0B0B",
        "name": "Pitch Black",
        "family": "Black"
      },
      {
        "family": "White",
        "name": "Chalk Ivory",
        "hex": "#EDECE8",
        "images": [
          "/uploads/1793432977454_whatsapp_image_2026_10_30_at_11_.jpeg",
          "/uploads/1793432985812_whatsapp_image_2026_10_30_at_11_.jpeg",
          "/uploads/1793433021364_whatsapp_image_2026_10_30_at_10_.jpeg"
        ]
      },
      {
        "name": "Forest Pine Green",
        "hex": "#243828",
        "family": "Green",
        "images": [
          "/uploads/1793432977454_whatsapp_image_2026_10_30_at_11_.jpeg",
          "/uploads/1793432985812_whatsapp_image_2026_10_30_at_11_.jpeg",
          "/uploads/1793433021364_whatsapp_image_2026_10_30_at_10_.jpeg"
        ]
      },
      {
        "images": [
          "/uploads/1793432977454_whatsapp_image_2026_10_30_at_11_.jpeg",
          "/uploads/1793432985812_whatsapp_image_2026_10_30_at_11_.jpeg",
          "/uploads/1793433021364_whatsapp_image_2026_10_30_at_10_.jpeg"
        ],
        "hex": "#162A43",
        "name": "Deep Cobalt Blue",
        "family": "Blue"
      },
      {
        "images": [
          "/uploads/1793432977454_whatsapp_image_2026_10_30_at_11_.jpeg",
          "/uploads/1793432985812_whatsapp_image_2026_10_30_at_11_.jpeg",
          "/uploads/1793433021364_whatsapp_image_2026_10_30_at_10_.jpeg"
        ],
        "name": "MAROON",
        "family": "Other",
        "hex": "#670404"
      },
      {
        "family": "Other",
        "hex": "#f0ade4",
        "name": "BABY PINK",
        "images": [
          "/uploads/1793432977454_whatsapp_image_2026_10_30_at_11_.jpeg",
          "/uploads/1793432985812_whatsapp_image_2026_10_30_at_11_.jpeg",
          "/uploads/1793433021364_whatsapp_image_2026_10_30_at_10_.jpeg"
        ]
      }
    ]
  },
  {
    "id": "void-mvw4136b",
    "badge": "NEW DROP",
    "fabric": "100% Ultra-Dense Combed Cotton",
    "name": "BLEEDING BUTTERFLY {HOODIE}",
    "backImage": "/uploads/1793433344529_whatsapp_image_2026_10_31_at_1_2.jpeg",
    "sizes": [
      "S",
      "M",
      "L",
      "XL",
      "XXL"
    ],
    "fit": "Signature Boxy Oversized Silhouette",
    "featured": true,
    "price": 1999,
    "createdAt": "2026-10-31T07:59:10.343Z",
    "colors": [
      {
        "images": [
          "/uploads/1793433352651_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793433344529_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793433371886_whatsapp_image_2026_10_31_at_1_2.jpeg"
        ],
        "name": "Pitch Black",
        "hex": "#0B0B0B",
        "family": "Black"
      },
      {
        "images": [
          "/uploads/1793433352651_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793433344529_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793433371886_whatsapp_image_2026_10_31_at_1_2.jpeg"
        ],
        "hex": "#EDECE8",
        "name": "Chalk Ivory",
        "family": "White"
      },
      {
        "name": "Forest Pine Green",
        "family": "Green",
        "hex": "#243828",
        "images": [
          "/uploads/1793433352651_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793433344529_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793433371886_whatsapp_image_2026_10_31_at_1_2.jpeg"
        ]
      },
      {
        "family": "Blue",
        "hex": "#162A43",
        "name": "Deep Cobalt Blue",
        "images": [
          "/uploads/1793433352651_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793433344529_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793433371886_whatsapp_image_2026_10_31_at_1_2.jpeg"
        ]
      },
      {
        "family": "Other",
        "name": "MAROON",
        "hex": "#770909",
        "images": [
          "/uploads/1793433352651_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793433344529_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793433371886_whatsapp_image_2026_10_31_at_1_2.jpeg"
        ]
      },
      {
        "images": [
          "/uploads/1793433352651_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793433344529_whatsapp_image_2026_10_31_at_1_2.jpeg",
          "/uploads/1793433371886_whatsapp_image_2026_10_31_at_1_2.jpeg"
        ],
        "name": "BABY PINK",
        "family": "Other",
        "hex": "#dd73d4"
      }
    ],
    "sku": "VW-10005",
    "isPublished": true,
    "images": [
      "/uploads/1793433352651_whatsapp_image_2026_10_31_at_1_2.jpeg",
      "/uploads/1793433344529_whatsapp_image_2026_10_31_at_1_2.jpeg",
      "/uploads/1793433371886_whatsapp_image_2026_10_31_at_1_2.jpeg"
    ],
    "angles": [
      {
        "label": "FRONT ANGLE",
        "url": "/uploads/1793433352651_whatsapp_image_2026_10_31_at_1_2.jpeg",
        "angle": "FRONT"
      },
      {
        "url": "/uploads/1793433344529_whatsapp_image_2026_10_31_at_1_2.jpeg",
        "angle": "BACK",
        "label": "REAR PROFILE"
      },
      {
        "angle": "SIDE",
        "url": "/uploads/1793433371886_whatsapp_image_2026_10_31_at_1_2.jpeg",
        "label": "SIDE SILHOUETTE"
      }
    ],
    "slug": "void-mvw4136b",
    "originalPrice": 3500,
    "category": "T-SHIRTS",
    "description": "Product Name: Bleeding Butterfly Hoodie (Voidwear Butterfly Collection)   Product OverviewStep beyond the ordinary with the \"Bleeding Butterfly\" hoodie from Voidwear. Built for those who wear their evolution proudly, this piece embodies the core message: \"Freedom, Transformation, A Stronger You.\" Featuring an intense, splattered butterfly graphic across the back, it fuses striking raw artistry with everyday comfort.   Key FeaturesStriking Back Graphic: High-impact \"Bleeding Butterfly\" artwork featuring sharp white, monochrome, and vivid crimson paint splatters set against a deep black hoodie.   Oversized Fit: Designed with a relaxed, drop-shoulder silhouette for the ultimate modern streetwear look and easy layering.   Premium Cotton Blend: Crafted from a soft, high-quality fabric blend that offers breathable comfort and cozy warmth.   Durable Print: High-definition printing technology ensures the intricate details and vibrant color contrasts stay sharp wash after wash.   Specifications & CareBrand/Collection: Voidwear – Butterfly Collection   Material: Premium Cotton Blend   Fit Type: Oversized Fit   Care Instructions: Machine wash cold inside out with like colors. Tumble dry low or hang dry. Do not iron directly on the graphic.The MessageFreedom. Transformation. A Stronger You.",
    "updatedAt": "2026-10-31T08:00:34.839Z",
    "inStock": true,
    "tagline": "HEAVYWEIGHT OVERSIZED UNISEX",
    "stockCount": 25,
    "details": [
      "Heavyweight 280 GSM luxury knit",
      "Reinforced rib neckline",
      "Distressed rear insignia"
    ],
    "gsm": 280,
    "sideImage": "/uploads/1793433371886_whatsapp_image_2026_10_31_at_1_2.jpeg",
    "careInstructions": [
      "Machine wash cold inside out",
      "Hang dry in shade",
      "Do not bleach"
    ]
  },
  {
    "id": "void-mvw48u89",
    "updatedAt": "2026-10-31T08:10:55.055Z",
    "stockCount": 25,
    "featured": true,
    "fabric": "100% Ultra-Dense Combed Cotton",
    "originalPrice": 2200,
    "slug": "void-mvw48u89",
    "careInstructions": [
      "Machine wash cold inside out",
      "Hang dry in shade",
      "Do not bleach"
    ],
    "createdAt": "2026-10-31T08:05:12.550Z",
    "fit": "Signature Boxy Oversized Silhouette",
    "price": 1200,
    "colors": [
      {
        "name": "Pitch Black",
        "images": [
          "/uploads/1793433660310_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793433667554_whatsapp_image_2026_10_31_at_1_4.jpeg"
        ],
        "hex": "#0B0B0B",
        "family": "Black"
      },
      {
        "hex": "#EDECE8",
        "family": "White",
        "name": "Chalk Ivory",
        "images": [
          "/uploads/1793433660310_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793433667554_whatsapp_image_2026_10_31_at_1_4.jpeg"
        ]
      },
      {
        "name": "Deep Cobalt Blue",
        "hex": "#162A43",
        "family": "Blue",
        "images": [
          "/uploads/1793433660310_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793433667554_whatsapp_image_2026_10_31_at_1_4.jpeg"
        ]
      },
      {
        "images": [
          "/uploads/1793433660310_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793433667554_whatsapp_image_2026_10_31_at_1_4.jpeg"
        ],
        "hex": "#243828",
        "name": "Forest Pine Green",
        "family": "Green"
      },
      {
        "family": "Other",
        "name": "MAROON",
        "hex": "#810909",
        "images": [
          "/uploads/1793433660310_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793433667554_whatsapp_image_2026_10_31_at_1_4.jpeg"
        ]
      },
      {
        "family": "Other",
        "images": [
          "/uploads/1793433660310_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793433667554_whatsapp_image_2026_10_31_at_1_4.jpeg"
        ],
        "hex": "#dd9cd5",
        "name": "BABY PINK"
      },
      {
        "name": "LAVENDER",
        "hex": "#859dff",
        "images": [
          "/uploads/1793433660310_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793433667554_whatsapp_image_2026_10_31_at_1_4.jpeg"
        ],
        "family": "Other"
      }
    ],
    "category": "T-SHIRTS",
    "backImage": "/uploads/1793433667554_whatsapp_image_2026_10_31_at_1_4.jpeg",
    "sku": "VW-10006",
    "description": "Product Name: Legacy of Lion T-Shirt (Voidwear Premium Oversized Streetwear)   Product OverviewMake a statement that outlasts the ordinary with the \"Legacy\" Lion T-shirt from Voidwear. As part of their premium oversized streetwear line, this piece is built on the creed: \"More than just a t-shirt\" and \"Legacy lives on. Wear your story.\" Featuring a clean, bold chest branding and a powerful, intricate lion portrait framed by laurel wreaths on the back, it is designed for those who command respect and leave a lasting impression.   Key FeaturesBold Graphic Design: Features crisp \"LEGACY\" chest typography complemented by a striking, highly-detailed lion head graphic and laurel wreath motif across the back.   Oversized Streetwear Fit: Cut with a modern, relaxed silhouette that delivers ultimate comfort and effortless styling.   100% Cotton Fabric: Made with pure, breathable cotton that ensures all-day comfort and superior softness.   Durable Craftsmanship: Built with premium neck ribs, high-quality printing, and durable stitching to ensure your tee stands the test of time.   Specifications & CareBrand/Collection: Voidwear – Premium Oversized Streetwear (\"Streetwear for the Real Ones\")   Material: 100% Cotton   Fit Type: Oversized Fit   Care Instructions: Machine wash cold inside out with like colors. Tumble dry low or hang dry. Do not iron directly on the graphic.The MessageLegacy Lives On. Wear Your Story.",
    "inStock": true,
    "sizes": [
      "S",
      "M",
      "L",
      "XL",
      "XXL"
    ],
    "details": [
      "Heavyweight 280 GSM luxury knit",
      "Reinforced rib neckline",
      "Distressed rear insignia"
    ],
    "angles": [
      {
        "label": "FRONT ANGLE",
        "url": "/uploads/1793433660310_whatsapp_image_2026_10_20_at_3_1.jpeg",
        "angle": "FRONT"
      },
      {
        "angle": "BACK",
        "url": "/uploads/1793433667554_whatsapp_image_2026_10_31_at_1_4.jpeg",
        "label": "REAR PROFILE"
      }
    ],
    "tagline": "HEAVYWEIGHT OVERSIZED 260 GSM UNISEX T SHIRT",
    "images": [
      "/uploads/1793433660310_whatsapp_image_2026_10_20_at_3_1.jpeg",
      "/uploads/1793433667554_whatsapp_image_2026_10_31_at_1_4.jpeg"
    ],
    "name": "LEGACY OF LION",
    "gsm": 280,
    "badge": "NEW DROP",
    "isPublished": true
  },
  {
    "id": "void-mvw7oq0q",
    "updatedAt": "2026-10-31T09:41:30.939Z",
    "isPublished": true,
    "slug": "void-mvw7oq0q",
    "sku": "VW-10007",
    "gsm": 280,
    "category": "T-SHIRTS",
    "name": "legacy of forest {t shirt}",
    "inStock": true,
    "stockCount": 25,
    "angles": [
      {
        "label": "FRONT ANGLE",
        "url": "/uploads/1793439582035_whatsapp_image_2026_10_20_at_3_1.jpeg",
        "angle": "FRONT"
      },
      {
        "angle": "BACK",
        "label": "REAR PROFILE",
        "url": "/uploads/1793439596165_whatsapp_image_2026_10_31_at_3_0.jpeg"
      }
    ],
    "createdAt": "2026-10-31T09:41:34.093Z",
    "description": "Product Name: Legacy Graphic Tee – Forest Green (Voidwear Legacy Collection)   Product OverviewBuild your future and wear your ambition with the \"Legacy\" Graphic Tee in Forest Green from Voidwear. Driven by the powerful mantras \"Same dreams, bigger moves\" and \"Legacy builds the future,\" this tee features a commanding lion emblem on the front and a rugged mountain range graphic on the back. It is designed for those who aim higher and move with purpose.   Key FeaturesDual-Sided Graphics: Bold \"LEGACY\" typography paired with an intricate lion crest on the front, complemented by a striking mountain range artwork on the back.   Oversized Streetwear Fit: Cut with a relaxed, modern drop-shoulder silhouette for effortless styling and maximum comfort.   Premium Cotton Fabric: Crafted from high-quality, breathable cotton built to deliver all-day comfort.   Durable Print & Stitching: High-definition printing technology ensures the graphics stay sharp and vibrant wear after wear.   Available Colors: Part of a versatile 6-color lineup including Black, White, Forest Green, Lavender, Maroon, and Baby Pink.   Specifications & CareBrand/Collection: Voidwear – Legacy Graphic Tee Collection   Material: Premium Cotton   Fit Type: Oversized Fit   Color: Forest Green (Also available in Black, White, Lavender, Maroon, and Baby Pink)   Care Instructions: Machine wash cold inside out with like colors. Tumble dry low or hang dry. Do not iron directly on the graphics.The MessageSame Dreams. Bigger Moves. Legacy Builds the Future.",
    "fabric": "100% Ultra-Dense Combed Cotton",
    "fit": "Signature Boxy Oversized Silhouette",
    "backImage": "/uploads/1793439596165_whatsapp_image_2026_10_31_at_3_0.jpeg",
    "featured": true,
    "badge": "NEW DROP",
    "tagline": "UNISEX 260 GSM OVERSIZED T SHIRT",
    "details": [
      "Heavyweight 280 GSM luxury knit",
      "Reinforced rib neckline",
      "Distressed rear insignia"
    ],
    "originalPrice": 2199,
    "price": 1200,
    "sizes": [
      "S",
      "M",
      "L",
      "XL",
      "XXL"
    ],
    "colors": [
      {
        "name": "Pitch Black",
        "family": "Black",
        "images": [
          "/uploads/1793439582035_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793439596165_whatsapp_image_2026_10_31_at_3_0.jpeg"
        ],
        "hex": "#0B0B0B"
      },
      {
        "images": [
          "/uploads/1793439582035_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793439596165_whatsapp_image_2026_10_31_at_3_0.jpeg"
        ],
        "name": "Chalk Ivory",
        "family": "White",
        "hex": "#EDECE8"
      },
      {
        "family": "Green",
        "hex": "#243828",
        "name": "Forest Pine Green",
        "images": [
          "/uploads/1793439582035_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793439596165_whatsapp_image_2026_10_31_at_3_0.jpeg"
        ]
      },
      {
        "family": "Blue",
        "hex": "#162A43",
        "name": "Deep Cobalt Blue",
        "images": [
          "/uploads/1793439582035_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793439596165_whatsapp_image_2026_10_31_at_3_0.jpeg"
        ]
      },
      {
        "images": [
          "/uploads/1793439582035_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793439596165_whatsapp_image_2026_10_31_at_3_0.jpeg"
        ],
        "name": "MAROON",
        "family": "Other",
        "hex": "#710909"
      },
      {
        "images": [
          "/uploads/1793439582035_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793439596165_whatsapp_image_2026_10_31_at_3_0.jpeg"
        ],
        "hex": "#9791ee",
        "name": "LAVENDER",
        "family": "Other"
      }
    ],
    "careInstructions": [
      "Machine wash cold inside out",
      "Hang dry in shade",
      "Do not bleach"
    ],
    "images": [
      "/uploads/1793439582035_whatsapp_image_2026_10_20_at_3_1.jpeg",
      "/uploads/1793439596165_whatsapp_image_2026_10_31_at_3_0.jpeg"
    ]
  },
  {
    "id": "void-mvw7y055",
    "slug": "void-mvw7y055",
    "careInstructions": [
      "Machine wash cold inside out",
      "Hang dry in shade",
      "Do not bleach"
    ],
    "stockCount": 25,
    "details": [
      "Heavyweight 280 GSM luxury knit",
      "Reinforced rib neckline",
      "Distressed rear insignia"
    ],
    "isPublished": true,
    "tagline": "OVERSIZED UNISEX 260 GSM T SHIRT",
    "originalPrice": 2299,
    "sku": "VW-10008",
    "gsm": 280,
    "category": "T-SHIRTS",
    "backImage": "/uploads/1793439758005_whatsapp_image_2026_10_31_at_3_0.jpeg",
    "name": "LEGACY OF EAGLE {T SHIRT}",
    "createdAt": "2026-10-31T09:48:45.707Z",
    "inStock": true,
    "sizes": [
      "S",
      "M",
      "L",
      "XL"
    ],
    "price": 1200,
    "description": "Product Name: Legacy Graphic Tee – The Eagle (Voidwear Premium Oversized Tee Collection)   Product OverviewSoar above the ordinary and wear your philosophy with the \"Legacy\" Eagle Graphic Tee from Voidwear. Part of the Premium Oversized Tee Collection under the creed \"More than a tee — it's a statement,\" this piece is built on the core principle: \"Discipline creates freedom\" and \"Timeless style builds legacy.\" Featuring minimalist chest branding paired with an intricate, majestic eagle soaring over a mountain landscape on the back, it is designed for those who forge their own path.   Key FeaturesDetailed Back Design & Minimalist Chest: Clean \"LEGACY\" typography on the chest, contrasted by a rich, highly detailed back graphic featuring an eagle, moon, mountains, and Japanese kanji accents.   Oversized Streetwear Fit: Cut with a relaxed, drop-shoulder silhouette for effortless styling and ultimate everyday comfort.   100% Cotton Fabric: Crafted from pure, breathable cotton that ensures a soft feel and long-lasting quality.   Durable Craftsmanship: Features a premium ribbed collar, durable stitching, and high-definition print technology designed to keep graphics sharp and vibrant.   Specifications & CareBrand/Collection: Voidwear – Premium Oversized Tee Collection (\"Built for Your Own Path\" / \"Legacy Lives On\")   Material: 100% Cotton   Fit Type: Oversized Fit   Care Instructions: Machine wash cold inside out with like colors. Tumble dry low or hang dry. Do not iron directly on the graphics.The MessageDiscipline Creates Freedom. Timeless Style Builds",
    "fabric": "100% Ultra-Dense Combed Cotton",
    "badge": "NEW DROP",
    "angles": [
      {
        "label": "FRONT ANGLE",
        "url": "/uploads/1793439751923_whatsapp_image_2026_10_20_at_3_1.jpeg",
        "angle": "FRONT"
      },
      {
        "url": "/uploads/1793439758005_whatsapp_image_2026_10_31_at_3_0.jpeg",
        "angle": "BACK",
        "label": "REAR PROFILE"
      }
    ],
    "fit": "Signature Boxy Oversized Silhouette",
    "images": [
      "/uploads/1793439751923_whatsapp_image_2026_10_20_at_3_1.jpeg",
      "/uploads/1793439758005_whatsapp_image_2026_10_31_at_3_0.jpeg"
    ],
    "colors": [
      {
        "name": "Pitch Black",
        "images": [
          "/uploads/1793439751923_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793439758005_whatsapp_image_2026_10_31_at_3_0.jpeg"
        ],
        "hex": "#0B0B0B",
        "family": "Black"
      },
      {
        "name": "Chalk Ivory",
        "family": "White",
        "hex": "#EDECE8",
        "images": [
          "/uploads/1793439751923_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793439758005_whatsapp_image_2026_10_31_at_3_0.jpeg"
        ]
      },
      {
        "family": "Green",
        "hex": "#243828",
        "name": "Forest Pine Green",
        "images": [
          "/uploads/1793439751923_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793439758005_whatsapp_image_2026_10_31_at_3_0.jpeg"
        ]
      },
      {
        "images": [
          "/uploads/1793439751923_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793439758005_whatsapp_image_2026_10_31_at_3_0.jpeg"
        ],
        "family": "Blue",
        "hex": "#162A43",
        "name": "Deep Cobalt Blue"
      },
      {
        "hex": "#650606",
        "name": "MAROON",
        "family": "Other",
        "images": [
          "/uploads/1793439751923_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793439758005_whatsapp_image_2026_10_31_at_3_0.jpeg"
        ]
      },
      {
        "name": "LAVENDER",
        "images": [
          "/uploads/1793439751923_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793439758005_whatsapp_image_2026_10_31_at_3_0.jpeg"
        ],
        "hex": "#96e8fd",
        "family": "Other"
      },
      {
        "family": "Other",
        "hex": "#f196fd",
        "images": [
          "/uploads/1793439751923_whatsapp_image_2026_10_20_at_3_1.jpeg",
          "/uploads/1793439758005_whatsapp_image_2026_10_31_at_3_0.jpeg"
        ],
        "name": "BABY PINK"
      }
    ],
    "featured": true,
    "updatedAt": "2026-10-31T09:49:29.191Z"
  }
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    name: 'Aarav Mehta',
    location: 'Mumbai, Maharashtra',
    rating: 5,
    date: '3 days ago',
    productName: 'bleeding butterfly {hoodie}',
    comment: 'The weight of this hoodie is unreal. Better drape and thickness than international labels charging ₹15,000+. The zero-drawstring collar stays up perfectly. Delivered to Bandra in 3 days.',
    verified: true
  },
  {
    id: 'rev-2',
    name: 'Kabir Singhania',
    location: 'New Delhi',
    rating: 5,
    date: '1 week ago',
    productName: 'THE SAMURAI ACID WASH {HOODIE}',
    comment: 'Oversized silhouette is genuinely designed by someone who understands modern streetwear proportions. The samurai back print and acid wash texture are incredible. Proud to see this quality coming out of Varanasi.',
    verified: true
  },
  {
    id: 'rev-3',
    name: 'Rohan Sharma',
    location: 'Bengaluru, Karnataka',
    rating: 5,
    date: '2 weeks ago',
    productName: 'THE FLORA {HOODIE}',
    comment: 'The botanical typography and graphic quality feels 100% custom. The packaging alone felt like opening a luxury fashion house unboxing. Ordered on WhatsApp directly with Akash and got instant tracking.',
    verified: true
  },
  {
    id: 'rev-4',
    name: 'Devansh Verma',
    location: 'Varanasi, UP',
    rating: 5,
    date: '3 weeks ago',
    productName: 'BLEEDING BUTTERFLY {SWEATSHIRT}',
    comment: 'Picked these up in Pandeypur. The tailoring is flawless, stacks over Jordans effortlessly. True luxury streetwear.',
    verified: true
  }
];

export const BRAND_INFO = {
  name: 'VOID WEAR',
  tagline: 'BEYOND ORDINARY',
  motto: 'ENTER THE VOID.',
  statement: 'NOT MADE FOR EVERYONE.',
  description: 'VOID WEAR is a premium streetwear label built around individuality, confidence and self-expression. Designed for those who refuse to blend in.',
  founder: 'Akash Goshwami',
  founderTitle: 'Founder & Creative Director',
  coFounder: 'Shivam Giri',
  coFounderTitle: 'Co-Founder & Managing Director',
  shivamPhone: '+917985986280',
  shivamPhoneDisplay: '+91 7985986280',
  location: 'Pandeypur, Varanasi, Uttar Pradesh, India',
  whatsappNumber: '+918114150537',
  whatsappDisplay: '+91 8114150537',
  phone: '+91 8114150537',
  email: 'voidwear1010@gmail.com',
  instagram: '@void__wear__',
  instagramUrl: 'https://instagram.com/void__wear__',
  businessHours: 'Open 7 days a week',
  currency: '₹',
  freeShippingThreshold: 1999
};
